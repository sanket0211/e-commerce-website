<?php echo $error;
echo $info ;

echo $user_name;
echo $user_id;
?>