# OAuth 2.0 Client

## Upgrade Guide

### Upgrading to Version 1.0.0

TBD
