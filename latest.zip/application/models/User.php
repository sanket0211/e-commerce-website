<?php
Class User extends CI_Model {
	public function __construct()
	{   
		$this->load->database();
		// TODO: Remove this line, and move user from unverified_user to user using controller
		$this->load->model('Unverified_User');
	} 
	
	public function fblogin($user_email){
		$this->db->select('user_id, user_name, user_email, user_password, user_phone');
		$this->db->from('Users');
		$this->db->where('user_email', $user_email);
		//$this->db->where('password', );
		//$this->db->limit(1);

		$query = $this->db->get();
		return $query->result();
		
	}

	public function login()
	{
		$user_email = $this->input->post('user_email');
		$user_password = $this->input->post('user_password');
		$this->db->select('user_id, user_name, user_email, user_password, user_phone');
		$this->db->from('Users');
		$this->db->where('user_email', $user_email);
		//$this->db->where('password', );
		//$this->db->limit(1);

		$query = $this->db->get();

		//print_r($query);
		if($query->num_rows() == 1)
		{
			//echo $query;
			//password_verify($password, $hash);
			$row = $query->row();
			if(password_verify($user_password, $row->user_password)){
				// user verified
				//print_r($query->result());
				return $query->result();
			}
			return NULL;
		}
		else
		{
			//echo "Not valid<br>";
			return false;
		}
	}

	private function setReferral($user_id){
		$result = $this->getUserProfile($user_id);
		$usname = $result->user_name;
		$len =(6 - strlen ( $user_id ));
		$lenname = strlen($usname);

		if($lenname >=$len){
			$usname = substr ( $usname , 0 , $len);
		}

		else{
			$rest = "abcdef";
			$usname = $usname . $rest;
			$usname = substr ( $usname , 0 , $len);
		}
		$ref = $usname . $user_id;
		$this->db->set('referral_code', $ref)  
                ->where('user_id', $user_id)
                ->update('Users');
	}

	public function updateUserName($user_id, $user_name){

		
		$this->db->set('user_name', $user_name, FALSE);
		$this->db->where('user_id', $user_id);
		$this->db->update('Users');
	}
	
	

	public function checkBalanceCoins($user_id=null){
		$this->db->select('user_coins');
		$this->db->from('Users');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();
		if ($query == FALSE) {
			return NULL;
		}
		$result = $query->result();
		return $result[0];
	}
	public function getAdsLimit($user_id){
		$this->db->select('ads_limit');
		$this->db->from('Users');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();
		if ($query == FALSE) {
			return NULL;
		}
		$result = $query->result();
		return $result[0];
	}

	public function updateAdsLimit($user_id,$newAdsLimit){
		if($newAdsLimit < 0) {
			$newAdsLimit=0;
		}
		$this->db->set('ads_limit', $newAdsLimit, FALSE);
		$this->db->where('user_id', $user_id);
		$this->db->update('Users');
	}

	public function addsharentoozbonus($user_id=NULL,$sharentoozbonus=NULL){
		$this->db->set('sharentoozbonus', 'sharentoozbonus+'.$sharentoozbonus, FALSE);
		$this->db->where('user_id', $user_id);
		$this->db->update('Users');	
	}

	public function subsharentoozbonus($user_id=NULL,$sharentoozbonus=NULL){
		
		$this->db->set('sharentoozbonus', 'sharentoozbonus-'.$sharentoozbonus, FALSE);
		$this->db->where('user_id', $user_id);
		$this->db->update('Users');	
	}

	public function getsharentoozbonus($user_id){
		$this->db->select('sharentoozbonus');
		$this->db->from('Users');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();

		$result = $query->result();
		return $result[0];
	}

	public function moveHere($unverified_user_id)
	{
		$this->db->select('unverified_user_id,unverified_user_address,referral,unverified_user_name,unverified_user_city_id,unverified_user_password,unverified_user_phone,
			unverified_user_email,unverified_user_img_name,unverified_user_img_name_ext,unverified_user_thumb_name');
		$this->db->where('unverified_user_id',$unverified_user_id);
		$query = $this->db->get('unverified_users')->result();
		$result = $query[0];
		
		$this->db->select('user_id,user_email,user_name, referral_code,user_coins');
		$this->db->where('referral_code',$result->referral);
		$this->db->from('Users');
		$query2 = $this->db->get();
		
		if($query2->conn_id->affected_rows>0){
			$initialcoins=200;
			$query2=$query2->result();
			$result2=$query2[0];
			$user2coins=$result2->user_coins + 50;
			$user2_id = $result2->user_id;
			$user2_email = $result2->user_email;
			$user2_name = $result2->user_name;
			$sql = "update Users set Users.user_coins = ? where Users.user_id = ?";
			$query = $this->db->query($sql, array($user2coins,$user2_id));

			//send email to user2 whose referral was used
			$this->email->from('support@rentooz.com','Rentooz');
			$this->email->to($user2_email);
			$this->email->subject('Refer and Earn Bonus');
			$email_msg = "Dear ".$user2_name. ",you have been awarded 50 gold coins for inviting a friend. Thank you. ";  
			$this->email->message($email_msg);
			$this->email->send();	
		
		}
		else{
			$initialcoins=100;
		
		}
		
		$usname = $result->unverified_user_name;
		$usid = $result->unverified_user_id;
		$len =(6 - strlen ( $usid ));
		$lenname = strlen($usname);
		if($lenname >=$len){
			$usname = substr ( $usname , 0 , $len);
		}
		else{
			$rest = "abcdef";
			$usname = $usname . $rest;
			$usname = substr ( $usname , 0 , $len);
		}
		$ref = $usname . $usid;
		//var_dump($result);
		$data = array(
			'user_name' => $result->unverified_user_name,
			'user_password' => $result->unverified_user_password,
			'user_phone' => $result->unverified_user_phone,
			'user_email' => $result->unverified_user_email,
			'city_id' => $result->unverified_user_city_id,
			'user_img_name' => $result->unverified_user_img_name,
			'user_img_ext' => $result->unverified_user_img_name_ext,
			'user_thumb_name' => $result->unverified_user_thumb_name,
			'referral_code' => $ref,
			'user_coins' => $initialcoins,
			'user_address'=>$result->unverified_user_address,

			'joined_date' => date('Y-m-d H:i:s')
		);
		$this->db->insert('Users',$data);
		$last_inserted_id = $this->db->insert_id();
		return $last_inserted_id;
	}
	
	// sent otp to mobile for verification
	public function gen_OTP($user_id = NULL){
		if(is_null($user_id)){ return NULL;}
		$this->delete($user_id);
		$charset = "1234567890";
		$otp = substr(str_shuffle($charset), 0, 4);
		$data = array(
			'user_id' => $user_id,
			'user_phone_otp' => $otp
		);
		$this->db->insert('verify_user', $data);
		$error = $this->db->error();
		if($error['code'] > 0) {
			return -1; // error
		}
		return $otp; // success
	}

	public function get_otp($user_id) {
		$this->db->select('user_phone_otp');
		$this->db->from('verify_user');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();
		if($query->num_rows() == 1)
		{
			$row = $query->row();
			return $row;
		}
		return -1;
	}
	
	public function delete($user_id = NULL){
		if(is_null($user_id)){ return NULL;}
		$this->db->delete('verify_user',array('user_id' => $user_id));
	}

	public function verify_mobile($user_id = NULL){
		$otp = $this->input->post('mob_otp');
		if(is_null($user_id) OR is_null($otp)){ return NULL;}
		$this->db->select('user_phone_otp');
		$this->db->where('user_id',$user_id);
		$this->db->from('verify_user');

		$query = $this->db->get();
		if($query->conn_id->affected_rows > 0){
			$otp_gen = $query->result()[0]->user_phone_otp;
			if($otp == $otp_gen){
				$this->delete($user_id);
				return 0; // verified
			}
		}
		return -1; // not verified
	}
	public function isMobileVerified($user_id = NULL){
		if(is_null($user_id)){ return NULL;}
		$this->db->select('user_phone_otp');
		$this->db->where('user_id', $user_id);
		$this->db->from('verify_user');

		$query = $this->db->get();
		//var_dump($query->conn_id->affected_rows);
		if($query->conn_id->affected_rows > 0){
			return 0; // not verified
		}
		return 1; // verified
	}
	
	
	

	public function isUser($user_email=null){

		$this->db->select('user_email');
		$this->db->where('user_email', $user_email);
		$this->db->from('Users');

		$query = $this->db->get();
		if($query->conn_id->affected_rows > 0){
			return 1; // not a rentooz user
		}
		return 0;
	}

	public function crosscheckpasswordchangecode($code){

		$this->db->select('user_email');
		$this->db->where('password_change_code', $code);
		$this->db->from('Forgotpassword');

		$query = $this->db->get();
		if($query->conn_id->affected_rows > 0){
			return 1; // not a rentooz user
		}
		return 0;
	}

	public function checkTable($user_email=null){

		$this->db->select('user_email');
		$this->db->where('user_email', $user_email);
		$this->db->from('Forgotpassword');

		$query = $this->db->get();
		if($query->conn_id->affected_rows > 0){
			$this->db->delete('Forgotpassword',array('user_email' => $user_email));
			return; // not a rentooz user
		}
		else{	
			return;
		}
	}

	public function getUserProfile($user_id = NULL)
	{
		if(!$user_id) {
			$this->db->select('user_id,user_name,user_phone,user_email,user_img_name,user_img_ext,user_address,user_earnings,user_coins');
			$this->db->from('Users');
			$query = $this->db->get();
			return $query->result();
		} else {
			$this->db->select('user_id,user_name,user_phone,user_email,user_img_name,user_img_ext,referral_code,joined_date,user_coins,user_earnings, offset,user_address,sharentoozbonus');
			$this->db->from('Users');
			$this->db->where('user_id', $user_id);
			$query = $this->db->get();
			if ($query == FALSE) {
				return NULL;
			}
			$result = $query->result();
			if(count($result) > 0) {
				return $result[0];
			}
			return NULL;
		}
	}

	// Use this function to get neccessary user details
	public function getUserInfo($user_id = NULL) {
		if(is_null($user_id)) {
			$this->db->select('user_id,user_name,user_phone,user_email,user_img_name,user_img_ext');
			$this->db->from('Users');
			$query = $this->db->get();
			return $query->result();
		} else {
			$this->db->select('user_id,user_name,user_phone,user_email,user_img_name,user_img_ext,joined_date');
			$this->db->from('Users');
			$this->db->where('user_id', $user_id);
			$query = $this->db->get();
			if ($query == FALSE) {
				return NULL;
			}
			$result = $query->result();
			if(count($result) > 0) {
				return $result[0];
			}
			return NULL;
		}
	}

	public function getNotInvitedMembers($user_id = NULL){
		$sql = "SELECT U.user_name,U.user_id,U.user_email,U.user_img_name,U.user_img_ext FROM Users as U where U.user_id != ?";
		$query = $this->db->query($sql, array($user_id));
		$error = $this->db->error();
        if($error['code'] > 0) {
            return -1; 
        }
		return $query->result();
	}

	
	public function UpdateCoins($get_coins= NULL, $user_id = NULL, $new_earnings=NULL){
		
		$sql = "update Users set Users.user_coins = ?, Users.user_earnings = ? where Users.user_id = ?";
		$query = $this->db->query($sql, array($get_coins, $new_earnings, $user_id));
		$error = $this->db->error();
	}

	// update borrower's offset after the giver accepted item request 
	public function UpdateOffset($user_id = NULL, $offset = NULL){
		if(is_null($user_id) OR is_null($offset)){
			return NULL;
		}
		$this->db->set('offset', 'offset+'.$offset, FALSE);
		$this->db->where('user_id', $user_id);
		$this->db->update('Users');
	}

	public function updatepassword($email){
		$pass = $this->input->post('user_password_new');
		$check = password_hash($this->input->post('user_password_new'),PASSWORD_DEFAULT);
		$this->db->set('user_password', $check, FALSE);
		$this->db->where('user_email', $email);
		$this->db->update('Users');
	}
	
	public function update_coins($user_id = NULL, $user_coins_diff = NULL){
		if(is_null($user_id) OR is_null($user_coins_diff)){
			return NULL;
		}
		$this->db->set('user_coins', 'user_coins+'.$user_coins_diff, FALSE);
		$this->db->where('user_id', $user_id);	
		$this->db->update('Users');
	}

	public function updateEarnings($user_id = NULL, $user_coins_diff = NULL){
		if(is_null($user_id) OR is_null($user_coins_diff)){
			return NULL;
		}
		$this->db->set('user_earnings', 'user_earnings+'.$user_coins_diff/10, FALSE);
		$this->db->where('user_id', $user_id);
		$this->db->update('Users');
	}

	public function NewEarnings($user_id = NULL, $earnings= NULL){
		if(is_null($user_id) OR is_null($earnings)){
			return NULL;
		}
		$this->db->set('user_earnings', 'user_earnings+('.$earnings.')', FALSE);
		$this->db->where('user_id', $user_id);
		$this->db->update('Users');
	}
	
	public function changeprofilephoto($user_id = NULL,$user_img_name,$user_img_ext,$user_thumb_name){
		
		if(is_null($user_id)) { return NULL; }
		$sql = "UPDATE Users SET user_img_name=?, user_img_ext=?, user_thumb_name=? WHERE Users.user_id=?";
		$query = $this->db->query($sql, array($user_img_name,$user_img_ext,$user_thumb_name,$user_id));
		
		return $query;
	}

	public function updatePhoneNumber($user_id = NULL){
		if(is_null($user_id)){
			return NULL;
		}

		$user_number = $this->input->post('user_phone');
		$this->db->set('user_phone', $user_number, FALSE);
		$this->db->where('user_id', $user_id);
		$this->db->update('Users');
	}

}
?>
